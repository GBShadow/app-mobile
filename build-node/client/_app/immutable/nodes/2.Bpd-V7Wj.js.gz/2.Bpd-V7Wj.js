import{_ as m}from"../chunks/CcxgTTQX.js";export{m as component};
